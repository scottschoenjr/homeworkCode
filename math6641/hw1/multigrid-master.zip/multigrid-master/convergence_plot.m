% Implementation of Mult-Grid Method.
%
%  Original Code (c) 2012 by Christian B. Mendl (see license)
%  Modified by Scott Schoen Jr
%
%   References:
%	  [1] Trottenberg, Oosterlee, Anton Schuller. "Multigrid",
%         Academic Press (2001)
%	  [2] LeVeque "Finite Difference Methods for Ordinary and Partial
%         Differential Equations" SIAM (2007)
%     

clear all
close all
clc

% Set parameters
n = 64; % Number of (square) grid points
maxIterations = 5;
numLevels = 3; % Number of levels to multigrid
nu1 = 1; % Number of pre-smoothing operations
nu2 = 1; % Number of post-smoothing operations
noColorMap = 1;
iterativeSolver = 'G-S'; % 'G-S' or 'Jacobi'/'J'

% Plotting options
plotRHS = 1;

whiteMap = ...
    [1, 1, 1; ...
     1, 1, 1 ...
    ];

% Create grid
[x,y] = meshgrid((1:(n-1))/n,(1:(n-1))/n);

% Define forcing term
R0 = 0.25;
f = 0.*x;
f( (x - 0.5).^(2) + (y - 0.5).^(2) < R0.^(2) ) = 1;
fColumnVector = reshape( f, [], 1 );

% Plot f if desired
if plotRHS
    figure();
    set( gca, 'Position', [0.15, 0.15, 0.7, 0.7] );
    surf(x,y,f);
    xlabel( '$x$', 'FontSize', 28, 'Interpreter', 'LaTeX' );
    ylabel( '$y$', 'FontSize', 28, 'Interpreter', 'LaTeX' );
    title( '$f(x, y)$', 'FontSize', 28, 'Interpreter', 'LaTeX' );
    if noColorMap
        colormap( whiteMap );
    end
end

% Compute exact solution
tic;
A = poissonStencil2D(n);
u_exact = A \ fColumnVector;
% u_exact = naive_gauss( A, fColumnVector );
toc;

% Plot exact solution
uPlot = reshape(u_exact, n-1, n-1);
figure();
set( gca, 'Position', [0.15, 0.15, 0.7, 0.7] );
surf(x, y, uPlot );
xlabel( '$x$', 'FontSize', 28, 'Interpreter', 'LaTeX' );
ylabel( '$y$', 'FontSize', 28, 'Interpreter', 'LaTeX' );
zlabel( '$u$', 'FontSize', 28, 'Interpreter', 'LaTeX' );
title( '$-\nabla^{2}u = f$', 'FontSize', 28, 'Interpreter', 'LaTeX' );
    if noColorMap
        colormap( whiteMap );
    end

% Compute multigrid solution

% Initialize error
err = cell(2,1);
for gamma = 1:4

    % Initialize error vector
	errG = zeros(maxIterations+1,1);

	% iterations of multigrid cycle
    
    % Initialize u
	u = zeros( (n-1)^2, 1);
    
    % Compute the error residual
	errG(1) = norm(u - u_exact);
    
    % For each iteration
	for iterationCount = 1 : maxIterations
		u = multigridCycle( ...
            n, gamma, u, @poissonStencil2D, fColumnVector, ...
            nu1, nu2, iterativeSolver );
	end
	
	% store error
	err{gamma} = errG;
end


%% Plot results!

figure();
hold all;
semilogy( 0:maxIterations, err{1} + 1E-9, 'ro' )
semilogy( 0:maxIterations, err{2} + 1E-9, 'ko');
legend('\gamma = 1','\gamma = 2');
xlabel('Iteration Number');
ylabel('Error');
title('Multi-Grid Solution');

% Plot solution from multigrid
uPlot = reshape(u, n-1, n-1);
figure();
set( gca, 'Position', [0.15, 0.15, 0.7, 0.7] );
surf(x, y, uPlot );
xlabel( '$x$', 'FontSize', 28, 'Interpreter', 'LaTeX' );
ylabel( '$y$', 'FontSize', 28, 'Interpreter', 'LaTeX' );
zlabel( '$u$', 'FontSize', 28, 'Interpreter', 'LaTeX' );
title( '$-\nabla^{2}u^{*} = f$', 'FontSize', 28, 'Interpreter', 'LaTeX' );
    if noColorMap
        colormap( whiteMap );
    end

% Plot iteration diagram
pointVector = 1 : ( 2.*numLevels - 1 );

levelVector = 0.*pointVector + numLevels;
for levelCount = 1 : numLevels
    levelVector( levelCount ) = numLevels - (levelCount - 1);
    levelVector( end - levelCount + 1 ) = numLevels - (levelCount - 1);
    
    % Get string for plot labels
    if levelCount == 1
        levelNoString = '$h$~~';
    else
        multiplier = 2^(levelCount - 1);
        levelNoString = ['$', num2str( multiplier ), 'h$~'];
    end
    yTickLabelVec{levelCount} = levelNoString;
    
end
plot( pointVector, levelVector, '-ok', 'MarkerFaceColor', 'k' );

ylim([0.75, numLevels + 0.25]);
xlim( [0.75, 2.*numLevels - 0.75] );
set( gca, ...
    'XTickLabel', '', ...
    'YTick', [1:numLevels], ...
    'YTickLabel', fliplr( yTickLabelVec ), ...
    'TickLabelInterpreter', 'LaTeX', ...
    'FontSize', 22 ....
    );
box off;
